#!/bin/shell

composer clear-cache