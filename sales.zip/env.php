<?php
// Database Config
$_ENV['DB_HOST'] = '127.0.0.1';
$_ENV['DB_NAME'] = 'reinte33_payment';
$_ENV['DB_USER'] = 'reinte33_payment_user';
$_ENV['DB_PASS'] = 'GanheComSorteEGanheBem@!3r22234';

// Assas Config
// API KEY PRODUCAO
//$_ENV['ASSAS_API'] = '$aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAzOTYwMTg6OiRhYWNoXzcwNmY2YzVhLWIzNmItNGQ0Mi1iOTE5LWQzNjZlOThkY2I1YQ==';
//$_ENV['ASSAS_ENV'] = 'producao';

// API KEY HOMOLOGACAO
$_ENV['ASSAS_API'] = '$aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAwNzQ2MTg6OiRhYWNoXzk1Y2JlNzc2LTMxYjctNGFmZi04MGMxLTM3ZDJkNjRkNjRmMw==';
$_ENV['ASSAS_ENV'] = 'homologacao';

// Senha para validar webhook's
$_ENV['WEBHOOK'] = '5sad8sa4asd56d4as68d56as4d8aw84d6as4d65a1d651a368w1das51de4w343rhjh74gf98hgfhnb17b879g49874hf5g6hg48f9';

// Valor de compra do Propheta
$_ENV['PROPHETA_PRICE'] = 6.30;
// Maximo de parcelas
$_ENV['PROPHETA_MAX_INSTALLMENTES'] = 1;
// Validar se vendas esta ativado
$_ENV['PROPHETA_SALE'] = true;


// Email commecial
$_ENV['PROPHETA_MAIL_COMMERCIAL'] = "commercial.propheta@hotmail.com";
$_ENV['PROPHETA_MAIL_COMMERCIAL_PASS'] = "9hasd897asgd6776ddygbiuwhu798huhn@3e33";